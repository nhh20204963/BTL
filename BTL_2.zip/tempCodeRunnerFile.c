truyvet(N,W,B,Weight,Value);
